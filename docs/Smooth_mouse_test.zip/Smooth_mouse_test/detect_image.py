import pyautogui
import time
import math
import multiprocessing

def detect_icon(image_path, x, y):
    icon_location = pyautogui.locateOnScreen(image_path, confidence=0.8)

    if icon_location:
        x1, y1, width, height = icon_location

        if x1 <= x <= (x1 + width) and y1 <= y <= (y1 + height):
            # The mouse cursor is within the icon's bounding box
            #print(f"Mouse cursor is over {image_path}.")
            return (x1 + width // 2, y1 + height // 2)  # Return icon center position

    return None

def main():
    prev_x, prev_y = pyautogui.position()
    prev_time = time.time()
    Speeds = []

    Image_list = ['7-calc.png', '8-calc.png', '9-calc.png']

    is_cursor_over_icon = False  # Variable to track if the cursor is over an icon
    icon_position = None  # Store the last detected icon position

    while True:
        x, y = pyautogui.position()

        current_time = time.time()
        time_elapsed = current_time - prev_time

        if time_elapsed > 0:
            delta_x = x - prev_x
            delta_y = y - prev_y

            speed_x = delta_x / time_elapsed
            speed_y = delta_y / time_elapsed
            newSpeed = int(math.hypot(speed_x, speed_y))
            Speeds.append(str(newSpeed))

            prev_x, prev_y = x, y
            prev_time = current_time

            #if len(Speeds) >= 2 and int(Speeds[-2]) != 0:
            #   velocity_ratio = int(newSpeed) / int(Speeds[-2])
            #else:
            #   velocity_ratio = 0

            #print('\r', end='')
            #output_line = f"Position : {x}, {y} | Vitesse : {newSpeed} pixels/secondes | Ratio de vitesse : {int(velocity_ratio)}".ljust(80)
            X = x
            Y = y

            # Create a pool of processes
            pool = multiprocessing.Pool()

            # Use the pool to parallelize icon detection
            results = [pool.apply_async(detect_icon, args=(image_path, X, Y)) for image_path in Image_list]

            # Close the pool of processes
            pool.close()

            # Wait for all processes to finish
            pool.join()

            # Process the results
            for result in zip(results, Image_list):
                icon_position = result.get()
                if icon_position is not None:
                    # Define a threshold for cursor proximity
                    proximity_threshold = 30  # Adjust as needed

                    # Check if the cursor is within the proximity threshold of the icon
                    if abs(x - icon_position[0]) <= proximity_threshold and abs(y - icon_position[1]) <= proximity_threshold:
                        # Move the cursor to the center of the icon
                        pyautogui.moveTo(icon_position[0], icon_position[1], duration=0.5)
                        is_cursor_over_icon = True
                    else:
                        # Cursor is not over the icon, release the mouse button
                        if is_cursor_over_icon:
                            pyautogui.mouseUp()
                            is_cursor_over_icon = False

        time.sleep(0.001)

if __name__ == "__main__":
    main()
