import pyautogui
import time
import math

prev_x, prev_y = pyautogui.position()
prev_time = time.time()
Speeds = []
X=0
Y=0
direction = 0

Image_list = ['7-calc.png','8-calc.png','9-calc.png']

while True:
    x, y = pyautogui.position()

    current_time = time.time()
    time_elapsed = current_time - prev_time

    if time_elapsed > 0:
        delta_x = x - prev_x
        delta_y = y - prev_y

        speed_x = delta_x / time_elapsed
        speed_y = delta_y / time_elapsed
        newSpeed = int(math.hypot(speed_x, speed_y))
        Speeds.append(str(newSpeed))

        prev_x, prev_y = x, y 
        prev_time = current_time

        if len(Speeds) >= 2 and int(Speeds[-2]) != 0:
            velocity_ratio = int(newSpeed) / int(Speeds[-2])
        else:
            velocity_ratio = 0

        # Efface la ligne précédente en imprimant des espaces pour garantir une longueur uniforme
        print('\r', end='')

        # Formatage de la ligne de sortie avec une longueur fixe
        output_line = f"Position : {x}, {y} | Vitesse : {newSpeed} pixels/secondes | Ratio de vitesse : {int(velocity_ratio)}".ljust(80)
        #print(output_line, end='')
        X=x  
        Y=y
        # Capture a screenshot of the entire screen
        #screenshot = pyautogui.screenshot('desktop_screenshot.png')

        from PIL import Image

        # Load the screenshot
        #screenshot = Image.open('desktop-screenshot.png')

        # Load the template image (icon image)
        icon_chrome = Image.open('7-calc.png')
        icon_8 = Image.open('8-calc.png')

        # Perform image recognition
        for image_path in Image_list:
        # Use locateOnScreen to find the image
            icon_location = pyautogui.locateOnScreen(image_path, confidence=0.9)

        x3 = icon_location.left
        y3 = icon_location.top

        if x3>=200 and x3<=1719:
            x1 = x3-200
            x2 = x3+200
        elif x3<200:
            x1 = 0
            x2 = x3+200
        elif x>1719:
            x1 = x3-200
            x2 = 1919

        if y3>=100 and y3<=1029:
            y1 = y3-100
            y2 = y3+100
        elif y<100:
            y1 = 0
            y2 = y3+100
        elif y>1029:
            y1 = y3-100
            y2 = 1029


        if x >x1 and x < x2:
            if y >y1 and y < y2:
                if icon_location:
                    # Icon found
                    pyautogui.moveTo(icon_location, duration=0)
                    #pyautogui.click(icon_location)
                    print(icon_location)
                else:
                    # Icon not found
                    print("Icon not found on the desktop.")
        
    time.sleep(0.001)