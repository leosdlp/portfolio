import pyautogui
import time

distance = 200

time.sleep(5)

while distance > 0:
    pyautogui.drag(distance, 0, duration=0.5)   # move right
    pyautogui.drag(0, -distance, duration=0.5)  # move up
    pyautogui.drag(-distance, 0, duration=0.5)  # move left
    pyautogui.drag(0, distance, duration=0.5)   # move down
    pyautogui.drag(0, distance=15, duration=0.5)  # move up

    distance -= 5
    pyautogui.drag(0, distance, duration=0.5)   # move down
    pyautogui.drag(-distance, 0, duration=0.5)  # move left
    distance -= 5
    pyautogui.drag(0, -distance, duration=0.5)  # move up