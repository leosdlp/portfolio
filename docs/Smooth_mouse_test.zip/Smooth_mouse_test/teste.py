import pyautogui
import math

# Nombre d'échantillons à prendre en compte pour la moyenne mobile
N = 50

# Liste pour stocker les positions précédentes de la souris
mouse_positions = []

# Seuil de vitesse pour activer le lissage
speed_threshold = 80  # Vous pouvez ajuster cette valeur selon vos besoins

# Liste pour stocker les directions de la souris
mouse_directions = []

# Seuil de changement de direction
direction_change_threshold = math.pi / 4  # 45 degrés (en radians)

# Nombre de changements de direction répétés nécessaires pour activer le lissage
repeated_direction_changes = 3

# Compteur de changements de direction
direction_change_count = 0

while True:
    # Obtenir la position actuelle de la souris
    x, y = pyautogui.position()
    
    # Ajouter la position actuelle à la liste des positions précédentes
    mouse_positions.append((x, y))
    
    # Limiter la taille de la liste aux N dernières positions
    if len(mouse_positions) > N:
        mouse_positions.pop(0)
    
    # Calculer la moyenne des N dernières positions
    avg_x = sum(pos[0] for pos in mouse_positions) / len(mouse_positions)
    avg_y = sum(pos[1] for pos in mouse_positions) / len(mouse_positions)
    
    # Calculer la vitesse actuelle de la souris
    speed = math.sqrt((avg_x - x)**2 + (avg_y - y)**2)
    
    # Calculer la direction actuelle de la souris
    if len(mouse_positions) > 1:
        last_x, last_y = mouse_positions[-2]
        direction = math.atan2(y - last_y, x - last_x)
        mouse_directions.append(direction)
    
    # Vérifier si la direction a changé brusquement
    if len(mouse_directions) > 1 and abs(mouse_directions[-1] - mouse_directions[-2]) > direction_change_threshold:
        direction_change_count += 1
    else:
        direction_change_count = 0
    
    # Si la vitesse dépasse le seuil et qu'il y a un changement de direction répété, déplacer la souris vers la position moyenne
    if speed > speed_threshold or direction_change_count >= repeated_direction_changes:
        pyautogui.moveTo(avg_x, avg_y, duration=0)  # Augmentez la durée selon vos préférences
    
    # Attendre un court instant pour éviter une boucle infinie très rapide
    #time.sleep(0.01)
