import pyautogui
import time
import math
import keyboard

prev_x, prev_y = pyautogui.position()
prev_time = time.time()
Speeds = []
X=0
Y=0
direction = 0
while True:
    x, y = pyautogui.position()

    current_time = time.time()
    time_elapsed = current_time - prev_time

    if time_elapsed > 0:
        delta_x = x - prev_x
        delta_y = y - prev_y

        speed_x = delta_x / time_elapsed
        speed_y = delta_y / time_elapsed
        newSpeed = int(math.hypot(speed_x, speed_y))
        Speeds.append(str(newSpeed))

        prev_x, prev_y = x, y 
        prev_time = current_time

        if len(Speeds) >= 2 and int(Speeds[-2]) != 0:
            velocity_ratio = int(newSpeed) / int(Speeds[-2])
        else:
            velocity_ratio = 0

        # Efface la ligne précédente en imprimant des espaces pour garantir une longueur uniforme
        print('\r', end='')

        # Formatage de la ligne de sortie avec une longueur fixe
        output_line = f"Position : {x}, {y} | Vitesse : {newSpeed} pixels/secondes | Ratio de vitesse : {int(velocity_ratio)}".ljust(80)
        #print(output_line, end='')
        
        if newSpeed > 40:
            if abs(x-X) > abs(y-Y):
                if X < x :
                    pyautogui.moveRel(20, 0, duration=0.2)
                    direction = 1
                    time.sleep(0.1)
                elif x < X :
                    pyautogui.moveRel(-20, 0, duration=0.2)  
                    direction = 2
                    time.sleep(0.1)
            elif abs(x-X) < abs(y-Y):
                if Y < y :
                    pyautogui.moveRel(0, 20, duration=0.2)
                    direction = 3
                    time.sleep(0.1)
                elif y < Y :
                    pyautogui.moveRel(0, -20, duration=0.2)
                    direction = 4
                    time.sleep(0.1)
        if keyboard.is_pressed('shift'):
            time.sleep(0.4)
        if keyboard.is_pressed('space'):
            pyautogui.click()  
        
        X=x  
        Y=y