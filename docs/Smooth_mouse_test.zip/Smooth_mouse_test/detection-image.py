import pyautogui
import time
import math

prev_x, prev_y = pyautogui.position()
prev_time = time.time()
Speeds = []
X=0
Y=0
direction = 0

Image_list = ['7-calc.png','8-calc.png','9-calc.png']

while True:
    x, y = pyautogui.position()

    current_time = time.time()
    time_elapsed = current_time - prev_time

    if time_elapsed > 0:
        delta_x = x - prev_x
        delta_y = y - prev_y

        speed_x = delta_x / time_elapsed
        speed_y = delta_y / time_elapsed
        newSpeed = int(math.hypot(speed_x, speed_y))
        Speeds.append(str(newSpeed))

        prev_x, prev_y = x, y 
        prev_time = current_time

        if len(Speeds) >= 2 and int(Speeds[-2]) != 0:
            velocity_ratio = int(newSpeed) / int(Speeds[-2])
        else:
            velocity_ratio = 0

        # Efface la ligne précédente en imprimant des espaces pour garantir une longueur uniforme
        print('\r', end='')

        # Formatage de la ligne de sortie avec une longueur fixe
        output_line = f"Position : {x}, {y} | Vitesse : {newSpeed} pixels/secondes | Ratio de vitesse : {int(velocity_ratio)}".ljust(80)
        #print(output_line, end='')
        X=x  
        Y=y
        # Capture a screenshot of the entire screen
        #screenshot = pyautogui.screenshot('desktop_screenshot.png')

        from PIL import Image

        # Load the screenshot
        #screenshot = Image.open('calc-screen.png')

        # Load the template image (icon image)
        icon_chrome = Image.open('7-calc.png')
        icon_8 = Image.open('8-calc.png')
        icon_9 = Image.open('9-calc.png')

        IconResult = {}

        for image_path in Image_list:
            icon_location = pyautogui.locateOnScreen(image_path, confidence=0.8)
            print(icon_location)
            nameX = image_path + ' x'
            nameY = image_path + ' y'
            x3 = icon_location.left
            y3 = icon_location.top
            IconResult[nameX] = x3
            IconResult[nameY] = y3
            if x3>=40 and x3<=1879:
                x1 = x3-40
                x2 = x3+40
            elif x3<40:
                x1 = 0
                x2 = x3+40
            elif x>1879:
                x1 = x3-40
                x2 = 1919

            if y3>=27 and y3<=1052:
                y1 = y-27
                y2 = y3+27
            elif y<27:
                y1 = 0
                y2 = y3+27
            elif y>1052:
                y1 = y3-27
                y2 = 1079


            if x >x1 and x < x2:
                if y >y1 and y < y2:
                    if icon_location:
                        # Icon found
                        pyautogui.moveTo(icon_location, duration=0)
                        print(icon_location)
                    else:
                        # Icon not found
                        print("Icon not found on the desktop.")
            print (IconResult) 
          




        
        
    time.sleep(0.001)
