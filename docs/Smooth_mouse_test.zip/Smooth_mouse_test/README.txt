Pour pouvoir utiliser les différentes fonctions il faut installer les dépendences ci-dessous:

-pip install pyautogui
-pip install keyboard

Ensuite il faut ajouter les icones nécessaires pour la détection car pour l'instant ça fonctionne seulement avec les touches 7,8 et 9 qui ont été utilisé pour les testes.




 