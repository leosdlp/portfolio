import pyautogui
import time
import math
prev_x, prev_y = pyautogui.position()
prev_time = time.time()
Speeds = []
X=0
Y=0
direction = 0

while True:
    x, y = pyautogui.position()

    current_time = time.time()
    time_elapsed = current_time - prev_time

    if time_elapsed > 0:
        delta_x = x - prev_x
        delta_y = y - prev_y

        speed_x = delta_x / time_elapsed
        speed_y = delta_y / time_elapsed
        newSpeed = int(math.hypot(speed_x, speed_y))
        Speeds.append(str(newSpeed))

        prev_x, prev_y = x, y 
        prev_time = current_time

        if len(Speeds) >= 2 and int(Speeds[-2]) != 0:
            velocity_ratio = int(newSpeed) / int(Speeds[-2])
        else:
            velocity_ratio = 0

        # Efface la ligne précédente en imprimant des espaces pour garantir une longueur uniforme
        print('\r', end='')

        # Formatage de la ligne de sortie avec une longueur fixe
        output_line = f"Position : {x}, {y} | Vitesse : {newSpeed} pixels/secondes".ljust(80)
        print(output_line, end='')
        X=x
        Y=y

    time.sleep(0.1)